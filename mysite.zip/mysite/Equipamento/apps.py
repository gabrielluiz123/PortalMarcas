from django.apps import AppConfig


class EquipamentoConfig(AppConfig):
    name = 'Equipamento'
