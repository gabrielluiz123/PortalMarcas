from django.apps import AppConfig


class DetalhesConfig(AppConfig):
    name = 'Detalhes'
