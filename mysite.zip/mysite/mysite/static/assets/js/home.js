import uComments from './vue.components/userComments.vue'
import planBox from './vue.components/plan.vue'
import techLogo from './vue.components/logos.vue'
import textSection from './vue.components/textSection.vue'
let data = {
    
}

// let comments = new Vue({
//     el: "#scraps",
//     data:{},
//     components:{
//         userComment: uComments
//     }
// })

